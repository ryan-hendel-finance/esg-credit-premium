"""
Chargement de la courbe des taux souverains zero coupon de la zone euro
publiee par la BCE (dataset YC, Svensson, notation AAA).

La courbe sert de reference sans risque : le spread de credit d'une
obligation est calcule comme son rendement moins le taux zero coupon
de meme maturite.

Source : ECB Data Portal, API publique et gratuite, sans authentification.
Documentation : https://data.ecb.europa.eu/help/api/overview
"""

from __future__ import annotations

import io

import numpy as np
import pandas as pd
import requests

ECB_BASE = "https://data-api.ecb.europa.eu/service/data"

# Series de la courbe zero coupon AAA de la zone euro, maturites en annees.
# Cle de serie : YC.B.U2.EUR.4F.G_N_A.SV_C_YM.SR_<maturite>Y
MATURITES_ECB = [1, 2, 3, 5, 7, 10, 15, 20, 30]


def _cle_serie(maturite_annees: int) -> str:
    return f"B.U2.EUR.4F.G_N_A.SV_C_YM.SR_{maturite_annees}Y"


def charger_courbe_ecb(date_obs: str, timeout: int = 30) -> pd.DataFrame:
    """
    Recupere la courbe zero coupon AAA de la zone euro a une date donnee.

    Parametres
    ----------
    date_obs : date au format 'AAAA-MM-JJ'. La BCE ne publie pas les jours
        feries et les week-ends : la fonction recupere une fenetre de dix
        jours et retient la derniere observation disponible.

    Retour
    ------
    DataFrame avec deux colonnes : maturite (annees) et taux (en pourcentage).
    """
    debut = (pd.Timestamp(date_obs) - pd.Timedelta(days=10)).strftime("%Y-%m-%d")
    lignes = []

    for maturite in MATURITES_ECB:
        url = f"{ECB_BASE}/YC/{_cle_serie(maturite)}"
        params = {
            "startPeriod": debut,
            "endPeriod": date_obs,
            "format": "csvdata",
        }
        reponse = requests.get(url, params=params, timeout=timeout)
        reponse.raise_for_status()

        serie = pd.read_csv(io.StringIO(reponse.text))
        if serie.empty:
            continue

        # On retient la derniere observation publiee avant la date demandee.
        derniere = serie.sort_values("TIME_PERIOD").iloc[-1]
        lignes.append({"maturite": float(maturite), "taux": float(derniere["OBS_VALUE"])})

    if not lignes:
        raise RuntimeError(
            "Aucune observation recuperee. Verifier la date ou la connexion reseau."
        )

    return pd.DataFrame(lignes).sort_values("maturite").reset_index(drop=True)


def courbe_de_secours() -> pd.DataFrame:
    """
    Courbe de repli utilisee lorsque l'API n'est pas accessible, par exemple
    derriere un pare-feu d'entreprise. Les niveaux correspondent a une courbe
    euro AAA legerement pentifiee et servent uniquement a faire tourner le
    code de bout en bout.
    """
    maturites = np.array(MATURITES_ECB, dtype=float)
    taux = np.array([2.05, 2.10, 2.18, 2.35, 2.52, 2.70, 2.88, 2.95, 3.00])
    return pd.DataFrame({"maturite": maturites, "taux": taux})


def interpoler_courbe(courbe: pd.DataFrame, maturites_cibles: np.ndarray) -> np.ndarray:
    """
    Interpole lineairement le taux zero coupon aux maturites des obligations.

    L'interpolation lineaire est volontairement simple. Une interpolation
    par splines cubiques sur les facteurs d'actualisation serait plus fine,
    mais l'ecart reste negligeable devant la dispersion des spreads de credit
    que l'on cherche a expliquer ici.
    """
    maturites_cibles = np.asarray(maturites_cibles, dtype=float)
    return np.interp(maturites_cibles, courbe["maturite"].values, courbe["taux"].values)
