"""
Chargement des donnees obligataires et des donnees d'emetteurs.

Deux modes sont prevus :

1. Mode reel : lecture de deux fichiers CSV que l'utilisateur constitue,
   data/obligations.csv et data/emetteurs.csv. Le format attendu est
   documente ci-dessous et un modele vide est fourni dans le depot.

2. Mode simulation : generation d'un echantillon synthetique calibre sur
   des ordres de grandeur realistes du marche euro investment grade.
   Ce mode permet de faire tourner l'ensemble de la chaine sans donnees,
   par exemple pour verifier le code ou presenter la methodologie.
   Les resultats obtenus en mode simulation ne sont evidemment pas des
   resultats de marche.

Format de data/obligations.csv
------------------------------
isin, emetteur, maturite_annees, rendement_pct, coupon_pct, montant_emis_meur

Format de data/emetteurs.csv
----------------------------
emetteur, secteur, notation, intensite_carbone, dette_nette_ebitda

    intensite_carbone : tonnes de CO2 equivalent (scopes 1 et 2) par million
        d'euros de chiffre d'affaires. Se calcule a partir du rapport de
        durabilite de l'emetteur, publie au titre de la CSRD.
    notation : notation composite S&P ou Moody's, format texte (AA-, A+, BBB).
    dette_nette_ebitda : levier financier, issu du rapport annuel.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

RACINE = Path(__file__).resolve().parents[1]
DOSSIER_DONNEES = RACINE / "data"

# Echelle de notation convertie en score numerique croissant avec le risque.
# La regression a besoin d'une variable ordonnee, pas d'une chaine de texte.
ECHELLE_NOTATION = {
    "AAA": 1, "AA+": 2, "AA": 3, "AA-": 4,
    "A+": 5, "A": 6, "A-": 7,
    "BBB+": 8, "BBB": 9, "BBB-": 10,
    "BB+": 11, "BB": 12, "BB-": 13,
}


def charger_donnees_reelles() -> pd.DataFrame:
    """Lit les deux CSV et les joint sur le nom de l'emetteur."""
    obligations = pd.read_csv(DOSSIER_DONNEES / "obligations.csv")
    emetteurs = pd.read_csv(DOSSIER_DONNEES / "emetteurs.csv")

    donnees = obligations.merge(emetteurs, on="emetteur", how="inner", validate="m:1")

    manquants = set(obligations["emetteur"]) - set(emetteurs["emetteur"])
    if manquants:
        print(f"Avertissement : {len(manquants)} emetteurs sans donnees extra-financieres, exclus.")

    return donnees


def generer_donnees_simulees(n_emetteurs: int = 32, graine: int = 42) -> pd.DataFrame:
    """
    Construit un echantillon synthetique d'obligations corporate euro.

    La simulation encode volontairement l'hypothese que l'on cherche a tester :
    une prime carbone qui n'existe pas sur les maturites courtes et qui
    apparait sur les maturites longues. Cela permet de verifier que la
    methodologie est capable de detecter l'effet lorsqu'il est present.
    Sur donnees reelles, l'effet peut parfaitement etre nul.
    """
    rng = np.random.default_rng(graine)

    secteurs = {
        "Utilities": (180, 60),
        "Materiaux": (420, 120),
        "Energie": (350, 110),
        "Industrie": (120, 40),
        "Consommation": (70, 25),
        "Sante": (35, 12),
        "Telecoms": (28, 10),
        "Technologie": (20, 8),
    }
    notations = ["AA-", "A+", "A", "A-", "BBB+", "BBB", "BBB-"]

    lignes_emetteurs = []
    for i in range(n_emetteurs):
        secteur = list(secteurs)[i % len(secteurs)]
        moyenne, ecart = secteurs[secteur]
        lignes_emetteurs.append({
            "emetteur": f"EMETTEUR_{i + 1:02d}",
            "secteur": secteur,
            "notation": rng.choice(notations, p=[0.05, 0.1, 0.2, 0.2, 0.2, 0.15, 0.1]),
            "intensite_carbone": max(5.0, rng.normal(moyenne, ecart)),
            "dette_nette_ebitda": np.clip(rng.normal(2.6, 1.0), 0.3, 6.0),
        })
    emetteurs = pd.DataFrame(lignes_emetteurs)
    emetteurs["score_notation"] = emetteurs["notation"].map(ECHELLE_NOTATION)

    lignes_obligations = []
    for _, emetteur in emetteurs.iterrows():
        for _ in range(rng.integers(3, 6)):
            maturite = float(np.clip(rng.gamma(3.0, 3.2), 1.0, 25.0))

            # Composante de risque de credit classique : notation et levier.
            spread = 25 + 14 * emetteur["score_notation"] + 12 * emetteur["dette_nette_ebitda"]
            # Prime de terme du credit : le spread s'elargit avec la maturite.
            spread += 3.5 * maturite
            # Effet carbone, actif seulement au dela de dix ans dans la simulation.
            carbone_norme = (emetteur["intensite_carbone"] - 150.0) / 100.0
            if maturite >= 10.0:
                spread += 11.0 * carbone_norme * (maturite - 10.0) / 5.0
            spread += rng.normal(0, 14)

            lignes_obligations.append({
                "isin": f"XS{rng.integers(1_000_000_000, 9_999_999_999)}",
                "emetteur": emetteur["emetteur"],
                "maturite_annees": maturite,
                "spread_bp": max(5.0, spread),
                "montant_emis_meur": float(rng.choice([300, 500, 750, 1000])),
            })

    obligations = pd.DataFrame(lignes_obligations)
    return obligations.merge(emetteurs, on="emetteur", how="left")


def preparer(donnees: pd.DataFrame) -> pd.DataFrame:
    """
    Prepare les variables utilisees par la regression.

    Le logarithme de l'intensite carbone est utilise plutot que le niveau brut,
    car la distribution des intensites est fortement asymetrique : un cimentier
    emet cent fois plus qu'un editeur de logiciels. Sans transformation, quelques
    emetteurs extremes domineraient l'estimation.
    """
    donnees = donnees.copy()

    if "score_notation" not in donnees.columns:
        donnees["score_notation"] = donnees["notation"].map(ECHELLE_NOTATION)

    inconnues = donnees["score_notation"].isna().sum()
    if inconnues:
        print(f"Avertissement : {inconnues} obligations avec une notation non reconnue, exclues.")
        donnees = donnees.dropna(subset=["score_notation"])

    donnees["log_carbone"] = np.log(donnees["intensite_carbone"].clip(lower=1.0))
    donnees["maturite_longue"] = (donnees["maturite_annees"] >= 10.0).astype(int)

    return donnees.reset_index(drop=True)
