"""
Production des graphiques du projet.

Trois visuels, chacun repondant a une question precise :

1. La dispersion des spreads en fonction de la maturite, coloree par
   intensite carbone. C'est le nuage de points brut, avant tout traitement.
2. Le spread residuel, une fois retires les effets de notation, de levier
   et de secteur, en fonction du carbone. C'est le graphique qui porte
   reellement le message du projet.
3. Le profil de la prime carbone estimee par tranche de maturite.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

RACINE = Path(__file__).resolve().parents[1]
DOSSIER_SORTIE = RACINE / "output"
DOSSIER_SORTIE.mkdir(exist_ok=True)

NAVY = "#1B2A4A"


def _mise_en_forme(ax, titre: str, x: str, y: str) -> None:
    ax.set_title(titre, fontsize=12, color=NAVY, pad=12)
    ax.set_xlabel(x, fontsize=10)
    ax.set_ylabel(y, fontsize=10)
    ax.grid(alpha=0.25, linestyle=":")
    for bord in ("top", "right"):
        ax.spines[bord].set_visible(False)


def nuage_spread_maturite(donnees: pd.DataFrame) -> Path:
    fig, ax = plt.subplots(figsize=(9, 5.5))
    nuage = ax.scatter(
        donnees["maturite_annees"],
        donnees["spread_bp"],
        c=donnees["log_carbone"],
        cmap="YlOrRd",
        s=42,
        alpha=0.85,
        edgecolor="white",
        linewidth=0.5,
    )
    barre = fig.colorbar(nuage, ax=ax)
    barre.set_label("Intensite carbone, echelle logarithmique", fontsize=9)
    _mise_en_forme(
        ax,
        "Spreads de credit euro par maturite et intensite carbone",
        "Maturite residuelle, annees",
        "Spread contre courbe souveraine, points de base",
    )
    chemin = DOSSIER_SORTIE / "01_nuage_spread_maturite.png"
    fig.tight_layout()
    fig.savefig(chemin, dpi=150)
    plt.close(fig)
    return chemin


def residus_contre_carbone(donnees: pd.DataFrame) -> Path:
    """
    Retire d'abord des spreads tout ce qui s'explique par la notation, le
    levier, la maturite et le secteur, puis represente ce qu'il reste en
    fonction du carbone. Si une relation apparait ici, elle n'est pas
    imputable a la qualite de credit.
    """
    modele = smf.ols(
        "spread_bp ~ score_notation + dette_nette_ebitda + maturite_annees + C(secteur)",
        data=donnees,
    ).fit()
    residus = modele.resid

    fig, ax = plt.subplots(1, 2, figsize=(12, 5), sharey=True)

    for indice, (libelle, masque) in enumerate([
        ("Maturites courtes, moins de 10 ans", donnees["maturite_annees"] < 10.0),
        ("Maturites longues, 10 ans et plus", donnees["maturite_annees"] >= 10.0),
    ]):
        x = donnees.loc[masque, "log_carbone"]
        y = residus[masque]
        ax[indice].scatter(x, y, s=38, alpha=0.75, color=NAVY, edgecolor="white", linewidth=0.5)

        if len(x) > 3:
            pente, ordonnee = np.polyfit(x, y, 1)
            grille = np.linspace(x.min(), x.max(), 50)
            ax[indice].plot(grille, pente * grille + ordonnee, color="#C0392B", linewidth=2)
            ax[indice].text(
                0.04, 0.94,
                f"pente : {pente:.1f} bp par unite de log carbone",
                transform=ax[indice].transAxes, fontsize=9, va="top", color="#C0392B",
            )

        ax[indice].axhline(0, color="grey", linewidth=0.8, linestyle="--")
        _mise_en_forme(
            ax[indice], libelle,
            "Intensite carbone, echelle logarithmique",
            "Spread residuel, points de base" if indice == 0 else "",
        )

    fig.suptitle(
        "Spread residuel apres neutralisation de la notation, du levier et du secteur",
        fontsize=12, color=NAVY,
    )
    chemin = DOSSIER_SORTIE / "02_residus_carbone.png"
    fig.tight_layout()
    fig.savefig(chemin, dpi=150)
    plt.close(fig)
    return chemin


def prime_par_tranche(donnees: pd.DataFrame) -> Path:
    """
    Estime le coefficient carbone tranche de maturite par tranche de maturite
    et represente son profil, avec un intervalle de confiance a 95 pour cent.
    """
    tranches = [(1, 5), (5, 8), (8, 12), (12, 18), (18, 30)]
    points, bornes_basses, bornes_hautes, etiquettes = [], [], [], []

    for debut, fin in tranches:
        sous = donnees[(donnees["maturite_annees"] >= debut) & (donnees["maturite_annees"] < fin)]
        if len(sous) < 12 or sous["secteur"].nunique() < 2:
            continue
        resultat = smf.ols(
            "spread_bp ~ log_carbone + score_notation + dette_nette_ebitda + C(secteur)",
            data=sous,
        ).fit(cov_type="cluster", cov_kwds={"groups": sous["emetteur"]})

        coefficient = float(resultat.params["log_carbone"])
        erreur = float(resultat.bse["log_carbone"])
        points.append(coefficient)
        bornes_basses.append(coefficient - 1.96 * erreur)
        bornes_hautes.append(coefficient + 1.96 * erreur)
        etiquettes.append(f"{debut} a {fin} ans")

    fig, ax = plt.subplots(figsize=(9, 5.5))
    positions = np.arange(len(points))
    ax.errorbar(
        positions, points,
        yerr=[np.array(points) - np.array(bornes_basses),
              np.array(bornes_hautes) - np.array(points)],
        fmt="o", color=NAVY, ecolor="#9AA5B1", elinewidth=2, capsize=5, markersize=8,
    )
    ax.axhline(0, color="#C0392B", linewidth=1.2, linestyle="--")
    ax.set_xticks(positions)
    ax.set_xticklabels(etiquettes)
    _mise_en_forme(
        ax,
        "Prime carbone estimee par tranche de maturite, intervalle a 95 pour cent",
        "Tranche de maturite residuelle",
        "Effet sur le spread, points de base par unite de log carbone",
    )
    chemin = DOSSIER_SORTIE / "03_prime_par_tranche.png"
    fig.tight_layout()
    fig.savefig(chemin, dpi=150)
    plt.close(fig)
    return chemin
