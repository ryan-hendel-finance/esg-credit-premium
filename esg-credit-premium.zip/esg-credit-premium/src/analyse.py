"""
Coeur analytique du projet.

L'idee centrale est simple a enoncer et facile a rater : une correlation brute
entre spread de credit et intensite carbone ne prouve rien. Les emetteurs les
plus carbones sont aussi, en moyenne, moins bien notes, plus endettes et plus
cycliques. Si l'on ne neutralise pas ces facteurs, on mesure la notation en
croyant mesurer le carbone.

La demarche retenue est donc :

1. Une regression naive, spread contre carbone seul, pour montrer ce que
   l'on obtiendrait sans precaution.
2. Une regression controlee, ajoutant la notation, le levier, la maturite
   et des effets fixes sectoriels.
3. Une estimation separee sur les maturites courtes et longues, puis un
   terme d'interaction, pour repondre a la question du projet : la prime
   carbone, si elle existe, se concentre-t-elle sur le long terme.

Les ecarts types sont regroupes par emetteur, car plusieurs obligations d'un
meme emetteur partagent les memes caracteristiques de credit et leurs residus
ne sont pas independants.
"""

from __future__ import annotations

import pandas as pd
import statsmodels.formula.api as smf


def regression_naive(donnees: pd.DataFrame):
    """Spread explique par le seul carbone. Sert de point de comparaison."""
    modele = smf.ols("spread_bp ~ log_carbone", data=donnees)
    return modele.fit(cov_type="cluster", cov_kwds={"groups": donnees["emetteur"]})


def regression_controlee(donnees: pd.DataFrame):
    """
    Spread explique par le carbone, une fois neutralises la qualite de credit,
    le levier, la maturite et le secteur.

    Le coefficient de log_carbone se lit comme l'effet en points de base d'un
    doublement de l'intensite carbone, multiplie par le logarithme de deux.
    """
    formule = (
        "spread_bp ~ log_carbone + score_notation + dette_nette_ebitda "
        "+ maturite_annees + C(secteur)"
    )
    modele = smf.ols(formule, data=donnees)
    return modele.fit(cov_type="cluster", cov_kwds={"groups": donnees["emetteur"]})


def regression_par_maturite(donnees: pd.DataFrame) -> dict:
    """
    Estime le meme modele controle separement sur les maturites courtes
    (moins de dix ans) et longues (dix ans et plus).
    """
    resultats = {}
    for libelle, sous_echantillon in [
        ("court terme, moins de 10 ans", donnees[donnees["maturite_annees"] < 10.0]),
        ("long terme, 10 ans et plus", donnees[donnees["maturite_annees"] >= 10.0]),
    ]:
        if len(sous_echantillon) < 15:
            print(f"Sous-echantillon trop petit pour '{libelle}', estimation ignoree.")
            continue
        resultats[libelle] = regression_controlee(sous_echantillon)
    return resultats


def regression_interaction(donnees: pd.DataFrame):
    """
    Modele avec terme d'interaction entre carbone et maturite.

    C'est la specification qui repond le plus directement a la question :
    le coefficient de l'interaction mesure de combien l'effet du carbone
    augmente par annee de maturite supplementaire. Un coefficient positif
    et significatif signifie que le marche price le risque de transition
    davantage sur les echeances lointaines.
    """
    formule = (
        "spread_bp ~ log_carbone * maturite_annees + score_notation "
        "+ dette_nette_ebitda + C(secteur)"
    )
    modele = smf.ols(formule, data=donnees)
    return modele.fit(cov_type="cluster", cov_kwds={"groups": donnees["emetteur"]})


def resume_coefficient(resultat, variable: str = "log_carbone") -> dict:
    """Extrait les elements a retenir d'une estimation."""
    if variable not in resultat.params.index:
        return {}
    return {
        "coefficient_bp": round(float(resultat.params[variable]), 2),
        "ecart_type": round(float(resultat.bse[variable]), 2),
        "t_statistique": round(float(resultat.tvalues[variable]), 2),
        "p_valeur": round(float(resultat.pvalues[variable]), 4),
        "n_observations": int(resultat.nobs),
        "r2_ajuste": round(float(resultat.rsquared_adj), 3),
    }


def table_synthese(donnees: pd.DataFrame) -> pd.DataFrame:
    """Assemble les resultats des differentes specifications dans un tableau."""
    lignes = []

    lignes.append({"specification": "Naive, carbone seul",
                   **resume_coefficient(regression_naive(donnees))})
    lignes.append({"specification": "Controlee, echantillon complet",
                   **resume_coefficient(regression_controlee(donnees))})

    for libelle, resultat in regression_par_maturite(donnees).items():
        lignes.append({"specification": f"Controlee, {libelle}",
                       **resume_coefficient(resultat)})

    interaction = regression_interaction(donnees)
    lignes.append({"specification": "Interaction carbone x maturite",
                   **resume_coefficient(interaction, "log_carbone:maturite_annees")})

    return pd.DataFrame(lignes)
